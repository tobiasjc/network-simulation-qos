def byte_to_mb(v):
    return (v * 8.0) / 1000000.00
